Invalid-file test archive.
